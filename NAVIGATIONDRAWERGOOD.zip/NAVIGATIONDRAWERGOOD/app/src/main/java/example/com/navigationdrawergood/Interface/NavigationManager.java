package example.com.navigationdrawergood.Interface;

public interface NavigationManager {

    void showFragment(String title);
}
