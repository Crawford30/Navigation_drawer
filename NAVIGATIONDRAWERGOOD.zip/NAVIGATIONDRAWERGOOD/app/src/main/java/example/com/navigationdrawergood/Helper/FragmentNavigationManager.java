package example.com.navigationdrawergood.Helper;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import example.com.navigationdrawergood.BuildConfig;
import example.com.navigationdrawergood.Fragments.FragmentContent;
import example.com.navigationdrawergood.Interface.NavigationManager;
import example.com.navigationdrawergood.MainActivity;

public class FragmentNavigationManager implements NavigationManager {
    private static FragmentNavigationManager mInstance;
    private FragmentManager mFragmentManager;
    private MainActivity mainActivity;

    public static FragmentNavigationManager getmInstance(MainActivity mainActivity){
        if(mInstance==null)

            mInstance = new FragmentNavigationManager();
                  mInstance.configure(mainActivity);
                  return mInstance;

    }

    private void configure(MainActivity mainActivity) {
        mainActivity=mainActivity;
        mFragmentManager=mainActivity.getSupportFragmentManager();
    }

    @Override
    public void showFragment(String title) {

        //FragmentManager fm = mFragmentManager;
        //FragmentTransaction ft = fm.beginTransaction().replace(R.id.container,)

        showFragment(FragmentContent.newInstance(title),false);
    }

    private void showFragment(Fragment fragmentContent, boolean b) {

        FragmentManager fm = mFragmentManager;
        FragmentTransaction ft = fm.beginTransaction().replace(R.id.container,fragmentContent);
        ft.addToBackStack(null);
        if(b || !BuildConfig.DEBUG)
            ft.commitAllowingStateLoss();
        else
            ft.commit();
        fm.executePendingTransactions();


    }


}
